defmodule M do

  def start_link do
    Agent.start_link(fn -> %{} end, name: __MODULE__)
	IO.puts "Debug Agent Started"
  end

  def hello(n1, n2) do

     M.start_link

    #    n1 = IO.gets("Enter Starting Number: ")    |> String.strip |> String.to_integer
    #n2 = IO.gets("Enter Ending Number: ")    |> String.strip |> String.to_integer
	 #IO.puts "Debug 1"
     range = n2-n1
     interval = div(range, 5)

     pid1 = spawn(fn() -> loop(n1, n1+interval) end)
     pid2 = spawn(fn() -> loop(n1+interval+1, n1+interval*2) end)
     pid3 = spawn(fn() -> loop(n1+interval*2+1, n1+interval*3) end)
     pid4 = spawn(fn() -> loop(n1+interval*3+1, n1+interval*4) end)
     pid5 = spawn(fn() -> loop(n1+interval*4+1, n2) end)

     :timer.sleep(300000)

     if !Process.alive?(pid1) and !Process.alive?(pid2) and !Process.alive?(pid3) and !Process.alive?(pid4) and !Process.alive?(pid5) do

        v = Agent.get(__MODULE__, fn(state) -> state end)
        Enum.each(v, fn ({key, value}) -> IO.puts "#{key} : #{Enum.join(value, " ")}" end)
		
	end	
	 
  end

  def pow(_, 0), do: 1
  def pow(k, n) when rem(n,2) == 1, do: k * pow(k, n - 1)
  def pow(k, n) do
  result = pow(k, div(n, 2))
  result * result
  end


  def loop(0,_), do: nil

  def loop(min, max) do

    if max < min do
      loop(0, min)
    else
      if rem(length(Integer.digits(min)), 2) == 0 do
        #IO.puts "Num is #{min} and length is #{length(Integer.digits(min))}"
        Enum.each(permutations(Integer.digits(min)), fn(x) ->

          if div(String.to_integer(Enum.join(x, "")), pow(10,div(length(Integer.digits(min)),2)))*rem(String.to_integer(Enum.join(x, "")), pow(10,div(length(Integer.digits(min)),2))) == min do

              #IO.puts "#{min} " <> Integer.to_string(div(String.to_integer(Enum.join(x, "")), pow(10,div(length(Integer.digits(min)),2)))) <> " " <> Integer.to_string(rem(String.to_integer(Enum.join(x, "")), pow(10,div(length(Integer.digits(min)),2))))

              Agent.update(__MODULE__, fn(state) ->

              Map.update(state, :"#{min}", [div(String.to_integer(Enum.join(x, "")), pow(10,div(length(Integer.digits(min)),2))), rem(String.to_integer(Enum.join(x, "")), pow(10,div(length(Integer.digits(min)),2)))], &(

              if !Enum.member?(Map.get(state, :"#{min}"), rem(String.to_integer(Enum.join(x, "")), pow(10,div(length(Integer.digits(min)),2)))) do
                &1 ++ [div(String.to_integer(Enum.join(x, "")), pow(10,div(length(Integer.digits(min)),2))), rem(String.to_integer(Enum.join(x, "")), pow(10,div(length(Integer.digits(min)),2)))]
              else
                [1 | &1] -- [1]
              end

              )
              )

              end)

          end
        end)
		#IO.puts "Debug X"

      end
      loop(min+1, max)
    end
  end

  def permutations([]), do: [[]]
  def permutations(list), do: for elem <- list, rest <- permutations(list--[elem]), do: [elem|rest]

end

M.hello(100000, 200000)
