defmodule M3 do



  def hello do

    IO.puts "Hello World!!!!!!"

  end

end
M3.hello
