defmodule Proj2.Application do
  use Application

  def start(_type, {num, topo, algo, startTime}) do
    children =
      if algo == "gossip" do
        [

          if topo == "rand2D" do
            {Proj2.Rand2D, {num, startTime}}
          else
            {Line, num}
          end

        ]
      else
        [
          if topo == "rand2D" do
            {Proj2.Rand2DPS, {num, startTime}}
          end
        ]
      end

    opts = [strategy: :one_for_one, name: Proj2.Supervisor]
    Supervisor.start_link(children, opts)
  end

end
