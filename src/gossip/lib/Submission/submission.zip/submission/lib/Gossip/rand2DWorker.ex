defmodule Proj2.Rand2D.Worker do
  use GenServer

  def start_link(_) do
    GenServer.start_link(__MODULE__, :no_args)
  end

  def init(:no_args) do
    {:ok, 0}
  end

  def handle_cast(:next, msgcount) do

    if(msgcount <= 9) do
      #IO.puts("Debug 5")
      nbor_pids = Proj2.Rand2D.get_nbors(self())
      GenServer.cast(Enum.random(nbor_pids), :next)
    end

    #IO.puts("Count = #{msgcount}")
    if(msgcount == 9) do
      #IO.puts("Debug 3")
      Proj2.Rand2D.term(self())
      #GenServer.cast(Proj2.Rand2D, :term)
    end

    {:noreply, msgcount + 1}
  end
end
